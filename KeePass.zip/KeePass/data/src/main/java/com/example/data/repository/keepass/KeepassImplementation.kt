package com.example.data.repository.keepass

enum class KeepassImplementation {
    KOTPASS
}