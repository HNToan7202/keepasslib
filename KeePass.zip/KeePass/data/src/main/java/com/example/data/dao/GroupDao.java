package com.example.data.dao;

import androidx.annotation.NonNull;


import com.example.data.entity.Group;
import com.example.data.result.OperationResult;

public interface GroupDao {
    @NonNull
    OperationResult<Group> getRootGroup();
}
