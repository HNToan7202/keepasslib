package com.example.data.entity

interface EncryptedDatabaseEntry : EncryptedDatabaseElement