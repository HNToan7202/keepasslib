package com.example.data.entity

enum class InheritableOptionType {
    BOOLEAN
}