package com.example.data.entity

interface EncryptedDatabaseElement