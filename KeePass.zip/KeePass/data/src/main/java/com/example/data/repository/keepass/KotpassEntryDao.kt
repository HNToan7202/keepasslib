package com.example.data.repository.keepass

import app.keemobile.kotpass.database.getEntry
import app.keemobile.kotpass.database.modifiers.modifyGroup
import app.keemobile.kotpass.database.modifiers.removeEntry
import app.keemobile.kotpass.models.Entry
import com.example.data.dao.EntryDao
import com.example.data.extension.getOrNull
import com.example.data.extension.getOrThrow
import com.example.data.extension.mapError
import com.example.data.extension.mapWithObject
import com.example.data.result.OperationError.GENERIC_MESSAGE_FAILED_TO_FIND_ENTITY_BY_UID
import com.example.data.result.OperationError.MESSAGE_FAILED_TO_FIND_NOTE
import com.example.data.result.OperationError.newDbError
import com.example.data.result.OperationResult
import com.example.data.result.Stacktrace
import java.util.UUID
import kotlin.math.max

class KotpassEntryDao(
    private val db: KotpassDatabase
) : EntryDao {
    override fun insert(entry: Entry): OperationResult<UUID?> {
        return insert(entry = entry, doCommit = true)
    }

    override fun remove(eId: UUID): OperationResult<Boolean> {

        val getEntryResult = getEntryById(eId)
        if (getEntryResult.isFailed) return getEntryResult.mapError()

        val getRecycleBinResult = db.getRecycleBinGroup()

        if (getRecycleBinResult.isFailed) {
            return getRecycleBinResult.mapError()
        }

        val entry = getEntryResult.obj

        val recycleBinGroup = getRecycleBinResult.getOrNull()

        val isInsideRecycleBin = if (recycleBinGroup != null) {
            val isInsideRecycleBinResult = db.isEntryInsideGroupTree(
                entryUid = eId,
                groupTreeRootUid = recycleBinGroup.uuid
            )

            if (isInsideRecycleBinResult.isFailed) {
                return isInsideRecycleBinResult.mapError()
            }

            isInsideRecycleBinResult.getOrThrow()
        } else {
            false
        }

        when {
            recycleBinGroup != null && !isInsideRecycleBin -> {
                // move to recycle bin
                val newEntry = entry?.copy(previousParentGroup = recycleBinGroup.uuid)
                newEntry?.let {
                    val updateResult = update(it, doCommit = false)
                    if (updateResult.isFailed) {
                        return updateResult.mapError()
                    }
                }

            }

            else -> {
                // remove permanently
                val newDb = db.getRawDatabase().removeEntry(uuid = eId)
                db.swapDatabase(newDb)
            }
        }

        val commitResult = db.commit().mapWithObject(entry)

        if (commitResult.isFailed) return commitResult.mapError()

        return commitResult.mapWithObject(true)
    }

    override fun getEntryById(entryUid: UUID): OperationResult<Entry?> {
        val result = db.getRawDatabase().getEntry { entry -> entry.uuid == entryUid }
            ?: return OperationResult.error(
                newDbError(
                    String.format(
                        GENERIC_MESSAGE_FAILED_TO_FIND_ENTITY_BY_UID,
                        Entry::class.simpleName,
                        entryUid
                    ), Stacktrace()
                )
            )
        val (rawGroup, rawEntry) = result

        return OperationResult.success(rawEntry)
    }

    override fun update(
        newEntry: Entry,
        doCommit: Boolean
    ): OperationResult<Entry> {

        val entryId = newEntry.uuid

        val getOldEntryResult = getEntryById(entryId)

        if (getOldEntryResult.isFailed) return getOldEntryResult.takeError()

        val oldEntry = getOldEntryResult.obj

        val getOldEntryAndGroupResult = db.getRawEntryAndGroupByUid(entryId)

        if (getOldEntryAndGroupResult.isFailed) return getOldEntryAndGroupResult.takeError()

        val (oldRawGroup, oldRawEntry) = getOldEntryAndGroupResult.getOrThrow()

        val isInTheSameGroup = (newEntry.previousParentGroup == oldEntry?.uuid)

        val prepareHistoryResult = prepareEntryHistory(oldRawEntry)

        if (prepareHistoryResult.isFailed) return prepareHistoryResult.mapError()

        val newHistory = prepareHistoryResult.getOrThrow()

        newEntry.copy(history = newHistory)

        val oldEntryIdx = oldRawGroup.entries.indexOfFirst { it.uuid == entryId }

        if (oldEntryIdx == -1) return OperationResult.error(
            newDbError(
                MESSAGE_FAILED_TO_FIND_NOTE,
                Stacktrace()
            )
        )

        var newDb = db.getRawDatabase()

        if (isInTheSameGroup) {
            newEntry.previousParentGroup?.let {
                newDb = newDb.modifyGroup(it) {
                    copy(
                        entries = entries.toMutableList().apply {
                            this[oldEntryIdx] = newEntry
                        }
                    )
                }
            }

        } else {
            oldEntry?.previousParentGroup?.let {
                newDb = newDb.modifyGroup(it) {
                    copy(
                        entries = entries.toMutableList().apply {
                            removeAt(oldEntryIdx)
                        }
                    )
                }
            }

            newEntry.previousParentGroup?.let {
                newDb = newDb.modifyGroup(it) {
                    copy(
                        entries = entries.toMutableList().apply {
                            add(newEntry)
                        }
                    )
                }
            }
        }
        db.swapDatabase(newDb)

        return db.commit().mapWithObject(newEntry)
    }


    private fun prepareEntryHistory(oldEntry: Entry): OperationResult<List<Entry>> {
        val getConfigResult = db.getConfig()
        if (getConfigResult.isFailed) {
            return getConfigResult.mapError()
        }

        val config = getConfigResult.getOrThrow()
        val history = if (config.maxHistoryItems > 0) {
            val excessiveHistoryItems = max(
                0,
                oldEntry.history.size + 1 - config.maxHistoryItems
            )

            oldEntry.history
                .drop(excessiveHistoryItems)
                .toMutableList()
                .apply {
                    add(oldEntry.copy(history = emptyList()))
                }
        } else {
            emptyList()
        }

        return OperationResult.success(history)
    }

    private fun insert(entry: Entry, doCommit: Boolean): OperationResult<UUID?> {
        val entryUUID = UUID.randomUUID()
        entry.copy(uuid = entryUUID)

        val groupUid = entry.previousParentGroup


        if (groupUid != null) {
            val getGroupResult = db.getRawGroupByUid(groupUid)
            if (getGroupResult.isFailed) {
                return getGroupResult.mapError()
            }
            val rawGroup = getGroupResult.obj
            val newEntries = rawGroup.entries.plus(entry)
            var newdb = db.getRawDatabase()

            val updatedGroup = rawGroup.copy(entries = rawGroup.entries + entry)

            newdb = newdb.modifyGroup(groupUid) {
                copy(
                    entries = newEntries
                )
            }
            db.swapDatabase(newdb)
            if (doCommit) {
                db.commit()
            }
            return OperationResult.success<UUID>(entryUUID)

        } else {
            return OperationResult<UUID>().mapError()
        }
    }


}