package com.example.data.file;

public enum OnConflictStrategy {
    CANCEL,
    REWRITE
}
