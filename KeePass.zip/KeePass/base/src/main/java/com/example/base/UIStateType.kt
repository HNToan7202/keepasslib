package com.example.yourpass.presentation.base

enum class UIStateType {
    LOADING,
    ERROR,
    SUCCESS,
    IDLE
}