package com.example.presentation.storage

import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import java.io.File
import javax.inject.Inject
import androidx.compose.runtime.State

@HiltViewModel
class SelectStorageViewModel @Inject constructor() : ViewModel() {

    private val _selectedIndex = mutableIntStateOf(-1)

    // Trạng thái file được chọn
    private val _selectedFile = mutableStateOf<File?>(null)
    val selectedFile: State<File?> get() = _selectedFile

    fun onFileSelected(file: File, index: Int) {
        _selectedFile.value = file
        _selectedIndex.intValue = index
    }
}
