package com.example.presentation.openandnew

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.presentation.R
import com.example.base.BaseScreen
import com.example.presentation.nav.Screen
import com.example.presentation.theme.Dimens
import com.example.presentation.theme.Styles

@Composable
fun OpenAndNewScreen(
    navController: NavController?, viewModel: OpenAndNewViewModel = hiltViewModel()
) {
    BaseScreen(
        uiState = viewModel.uiState.value,
        onErrorDismiss = {
            viewModel.setIdle()
        },
        onSuccessDismiss = {
            viewModel.setIdle()
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(Dimens.PaddingLarge),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Image(
                    painter = painterResource(R.drawable.password_manager),
                    modifier = Modifier
                        .padding(top = 70.dp)
                        .width(120.dp)
                        .height(120.dp),
                    contentDescription = null
                )

                Text(
                    modifier = Modifier.padding(top = 70.dp),
                    text = "YourPassword",
                    style = Styles.Heading
                )

                Button(
                    onClick = { navController?.navigate(Screen.NewDatabaseScreen.route) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = Dimens.PaddingLarge)
                ) {
                    Text("Create New Database")
                }

                Button(
                    onClick = {
                        navController?.navigate(Screen.StorageListScreen.route)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = Dimens.PaddingLarge)
                ) {
                    Text("Open Database")
                }

                Text(
                    "Open Recent", modifier = Modifier
                        .padding(top = 16.dp)
                        .fillMaxWidth()
                )

                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    thickness = 1.dp,
                    color = Color.Gray
                )

                LazyColumn {

                }
            }
        }
    )
}

@Composable
@Preview(showSystemUi = true)
fun OpenAndNewScreenPreview() {
    OpenAndNewScreen(
        navController = null,
        viewModel = hiltViewModel()
    )
}
