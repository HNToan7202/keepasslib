package com.example.presentation.home.component

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import app.keemobile.kotpass.models.Entry
import com.example.presentation.home.HomeViewModel
import com.example.presentation.nav.Screen

@Composable
fun EntryListScreen(
    entries: List<Entry>,
    navController: NavController,
    modifier: Modifier,
    viewModel: HomeViewModel,
    onItemLongClick: (Entry) -> Unit // Sự kiện long click
) {

    LazyColumn(modifier = modifier) {
        items(entries.size) { i ->
            val entry = entries[i]
            EntryListItem(entry = entry, onItemClick = {

                navController.currentBackStackEntry?.savedStateHandle
                    ?.set(Screen.DetailEntryScreen.ARG_NOTE, entry.uuid)

                navController.navigate("${Screen.DetailEntryScreen.route}/${entry.uuid}")

            }, onItemLongClick = onItemLongClick, viewModel, navController)
        }
    }
}