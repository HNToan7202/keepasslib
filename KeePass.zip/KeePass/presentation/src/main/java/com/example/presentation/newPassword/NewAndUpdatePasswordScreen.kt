package com.example.presentation.newPassword

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.presentation.R
import com.example.base.BaseScreen
import com.example.presentation.nav.AppTopBar

@Composable
fun NewAndUpdatePasswordScreen(
    navController: NavController,
    viewModel: NewPasswordViewModel = hiltViewModel(),
    isEditMode: Boolean = false
) {
    val titleText = if (isEditMode) "Update Entry" else "New Entry"
    val buttonText = if (isEditMode) "Update Entry" else "Add Entry"
    BaseScreen(uiState = viewModel.uiState.value, onSuccessDismiss = {
        navController.popBackStack()
    }, onErrorDismiss = {
        viewModel.setIdle()
    }) {
        Scaffold(
            topBar = {
                AppTopBar(titleText, navController, actions = {
                    IconButton(onClick = {
                        viewModel.submit()
                    }) {}
                })
            },

            ) { paddingValue ->
            Column(
                modifier = Modifier
                    .padding(paddingValue)
                    .padding(horizontal = 16.dp)
            ) {

                OutlinedTextField(
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_badge_24),
                            contentDescription = null
                        )
                    },
                    value = viewModel.title,
                    onValueChange = { viewModel.updateTitle(it) },
                    label = { Text("Title") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {})

                OutlinedTextField(
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_account_circle_24),
                            contentDescription = null
                        )
                    },
                    value = viewModel.userName,
                    onValueChange = { viewModel.updateUserName(it) },
                    label = { Text("Username") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {})

                OutlinedTextField(
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_vpn_key_24),
                            contentDescription = null
                        )
                    },
                    value = viewModel.password,
                    onValueChange = { viewModel.updatePassword(it) },
                    label = { Text("Password") },
                    visualTransformation = if (viewModel.isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { viewModel.togglePasswordVisibility() }) {
                            Icon(
                                painter = painterResource(
                                    if (viewModel.isPasswordVisible) R.drawable.ic_eye_open else R.drawable.ic_eye_close
                                ),
                                contentDescription = if (viewModel.isPasswordVisible) "Hide password" else "Show password"
                            )
                        }
                    })

                OutlinedTextField(
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_vpn_key_24),
                            contentDescription = null
                        )
                    },
                    value = viewModel.confirmPassword,
                    onValueChange = { viewModel.updateConfirmPassword(it) },
                    label = { Text("Confirm") },
                    visualTransformation = if (viewModel.isConfirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { viewModel.toggleConfirmPasswordVisibility() }) {
                            Icon(
                                painter = painterResource(
                                    if (viewModel.isConfirmPasswordVisible) R.drawable.ic_eye_open else R.drawable.ic_eye_close
                                ),
                                contentDescription = if (viewModel.isConfirmPasswordVisible) "Hide password" else "Show password"
                            )
                        }
                    })

                OutlinedTextField(
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_link_24),
                            contentDescription = null
                        )
                    },
                    value = viewModel.url,
                    onValueChange = { viewModel.updateURL(it) },
                    label = { Text("URL") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {})


                OutlinedTextField(
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_notes_24),
                            contentDescription = null
                        )
                    },
                    value = viewModel.note,
                    onValueChange = { viewModel.updateNote(it) },
                    label = { Text("Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {})

                Button(
                    onClick = {
                        viewModel.submit()
                    }, modifier = Modifier
                        .padding(top = 8.dp)
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    Text(
                        buttonText,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )
                }
            }

        }
    }

}