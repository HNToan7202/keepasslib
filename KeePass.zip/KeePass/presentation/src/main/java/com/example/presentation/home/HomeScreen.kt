package com.example.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.sharp.Add
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.presentation.R
import com.example.base.BaseScreen
import com.example.presentation.components.EmptyStateView
import com.example.presentation.home.component.BottomSheetMenuItem
import com.example.presentation.home.component.EntryListScreen
import com.example.presentation.home.component.MenuItem
import com.example.presentation.nav.HomeTopBar
import com.example.presentation.nav.Screen
import com.example.presentation.theme.OnPrimaryColor
import com.example.presentation.theme.PrimaryColor
import com.example.presentation.theme.Styles
import com.example.presentation.theme.windowInsetsVerticalZero
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val entries = viewModel.entries.collectAsState().value
    val showSettingsMenu = viewModel.showSettingsMenu.value

    val showBottomSheet = viewModel.showBottomSheet.value

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()

    val currentBackStackEntry = navController.currentBackStackEntryAsState().value

    LaunchedEffect(currentBackStackEntry) {
        if (currentBackStackEntry?.destination?.route == Screen.HomeScreen.route) {
            viewModel.updateEntries()
        }
    }

    if (showBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = {
                viewModel.toggleBottomSheet(false)
            },
            sheetState = sheetState
        ) {
            Column {
                Text(
                    "Add new",
                    style = Styles.BodyMediumBold,
                    modifier = Modifier.padding(top = 16.dp, start = 16.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                val menuItems = listOf(
                    MenuItem("Password", painterResource(R.drawable.ic_password_out_line)),
                    MenuItem("Secure Note", painterResource(R.drawable.ic_sticky_note)),
                    MenuItem("Credit Card", painterResource(R.drawable.ic_credit_card)),
                    MenuItem("Folder", painterResource(R.drawable.new_folder)),
                )

                LazyColumn {
                    items(menuItems.size) { i ->
                        BottomSheetMenuItem(menuItems[i]) {
                            viewModel.toggleBottomSheet(false)
                            navController.navigate(Screen.NewPasswordScreen.createRoute("create"))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    BaseScreen(
        uiState = viewModel.uiState.value,
        onErrorDismiss = {},
        onSuccessDismiss = {},
        content = {
//                    HomeTopBar("Manage Password", actions = {
//                        Box {
//                            IconButton(onClick = { viewModel.toggleBottomSheet(true) }) {
//                                Icon(
//                                    tint = OnPrimaryColor,
//                                    painter = painterResource(R.drawable.outline_add_box_24),
//                                    contentDescription = "Add"
//                                )
//                            }
//                        }
//
//                        Box {
//                            IconButton(onClick = { viewModel.onToggleSettingsMenu(true) }) {
//                                Icon(
//                                    tint = OnPrimaryColor,
//                                    painter = painterResource(R.drawable.ic_setting),
//                                    contentDescription = "Settings"
//                                )
//                            }
//                            DropdownMenu(
//                                expanded = showSettingsMenu,
//                                onDismissRequest = { viewModel.onToggleSettingsMenu(false) }
//                            ) {
//                                DropdownMenuItem(
//                                    text = { Text("Database Setting") },
//                                    onClick = {
//                                        viewModel.onToggleSettingsMenu(false)
//                                        navController.navigate(Screen.DatabaseSettingScreen.route)
//                                    }
//                                )
//
//                                DropdownMenuItem(
//                                    text = { Text("App Setting") },
//                                    onClick = {
//                                        viewModel.onToggleSettingsMenu(false)
//                                    }
//                                )
//                            }
//                        }
//                })
            Scaffold(
                floatingActionButton = {
                    FloatingActionButton(onClick = { viewModel.toggleBottomSheet(true) }) {
                        Icon(
                            imageVector = Icons.Sharp.Add,
                            contentDescription = stringResource(R.string.accessibility_add_item)
                        )
                    }
                },
                topBar = {
                    CenterAlignedTopAppBar(
                        title = { Text(stringResource(R.string.title_passwords)) },
                        modifier = Modifier
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() }
                            ) {
                            },
                        navigationIcon = {
                            IconButton(onClick = { }) {
                                Icon(
                                    imageVector = Icons.Outlined.Lock,
                                    contentDescription = stringResource(R.string.accessibility_lock_application)
                                )
                            }
                        },
                        actions = {
                            IconButton(onClick = { }) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_sort_24),
                                    contentDescription = stringResource(R.string.accessibility_sort)
                                )
                            }
                        },
                        windowInsets = windowInsetsVerticalZero,
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            scrolledContainerColor = MaterialTheme.colorScheme.surface
                        ),
                        scrollBehavior = scrollBehavior,
                    )
                },

                ) { paddingValue ->
                val modifier = Modifier.padding(paddingValue)
                if (entries.isEmpty()) {
                    EmptyStateView(modifier = modifier, title = R.string.text_no_passwords)
                } else {
                    Column(modifier = modifier) {
                        EntryListScreen(
                            entries,
                            navController,
                            Modifier.padding(),
                            onItemLongClick = {}, viewModel = viewModel
                        )
                    }

                }
            }
        }
    )
}