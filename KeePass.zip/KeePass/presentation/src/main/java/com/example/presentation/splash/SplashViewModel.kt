package com.example.presentation.splash

import com.example.data.repository.SharedPreferencesRepository
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val sharedPreferencesRepository: SharedPreferencesRepository
) : BaseViewModel() {

    fun getLastFilePath(): String? {
        return sharedPreferencesRepository.getLastFilePath()
    }

    fun getLastFileName(): String? {
        return sharedPreferencesRepository.getLastFileName()
    }
}