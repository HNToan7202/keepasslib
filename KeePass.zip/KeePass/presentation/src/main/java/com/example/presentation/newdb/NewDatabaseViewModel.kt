package com.example.presentation.newdb

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.keemobile.kotpass.cryptography.EncryptedValue
import app.keemobile.kotpass.database.Credentials
import com.example.data.entity.FSAuthority.Companion.INTERNAL_FS_AUTHORITY
import com.example.data.entity.FSType
import com.example.data.entity.FileDescriptor
import com.example.data.file.FSOptions
import com.example.data.repository.SharedPreferencesRepository
import com.example.data.repository.keepass.kotpass.KeepassDatabaseRepository
import com.example.data.repository.keepass.KotpassDatabase
import com.example.data.repository.keepass.PasswordKeepassKey
import com.example.data.utils.FileUtils
import com.example.data.utils.FileUtils.createPath
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject

@HiltViewModel
class NewDatabaseViewModel @Inject constructor(
    private val keepassDatabaseRepository: KeepassDatabaseRepository,
    private val sharedPreferencesRepository: SharedPreferencesRepository,
) : BaseViewModel() {

    var fileName by mutableStateOf("")
    var filenameError by mutableStateOf("")
    var passwordError by mutableStateOf("")
    var confirmationError by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmPassword by mutableStateOf("")
    var isAddTemplatesChecked by mutableStateOf(true)
    var storagePath by mutableStateOf("")
    var result by mutableIntStateOf(-1)
    var isPasswordVisible by mutableStateOf(false)
    var isConfirmPasswordVisible by mutableStateOf(false)

    fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
    }

    fun toggleConfirmPasswordVisibility() {
        isConfirmPasswordVisible = !isConfirmPasswordVisible
    }

    fun updatePath(context: Context) {
        storagePath = context.filesDir.absolutePath
    }

    fun onResultChanged(returnedValue: Int) {
        result = returnedValue
    }

    fun updateFileName(name: String) {
        fileName = name
    }

    fun updatePassword(passwordValue: String) {
        password = passwordValue
    }

    fun updateConfirmPassword(passwordValue: String) {
        confirmPassword = passwordValue
    }

    fun updateTemplatesChecked(isChecked: Boolean) {
        isAddTemplatesChecked = isChecked
    }

    fun handleSavedState(savedStateHandle: SavedStateHandle?) {
        val returnedValue = savedStateHandle?.remove<Int>("selectedIndex")
        returnedValue?.let {
            result = it
        }
    }

    fun canSubmit(): Boolean {
        return fileName.isNotBlank() &&
                password.isNotBlank() &&
                confirmPassword.isNotBlank() &&
                password == confirmPassword
    }

    fun createNewDatabaseFile() {
        if (!isFieldsValid()) return

        if (isFileAlreadyExists()) {
            setError("File đã tồn tại, hãy chọn tên khác")
            return
        }

        val dbFile = createDbFile()
        val credentials = Credentials.from(EncryptedValue.fromString(password))

        viewModelScope.launch {

            setLoading()
            try {
                val result = withContext(Dispatchers.IO) {
                    keepassDatabaseRepository.createNewDatabase(
                        credentials,
                        FSOptions.DEFAULT,
                        dbFile,
                    )
                }

                if (result.isSucceeded) {
                    Timber.d("Keepass: Success")
                    val dbKey = PasswordKeepassKey(password)
                    keepassDatabaseRepository.setDatabase(
                        result.obj,
                        FSOptions.DEFAULT,
                        dbFile,
                        dbKey
                    )
                    sharedPreferencesRepository.saveLastFilePath(dbFile.path)
                    sharedPreferencesRepository.saveLastFileName(fileName)
                    setSuccess()
                } else {
                    setError("Tạo cơ sở dữ liệu thất bại.")
                }
            } catch (e: Exception) {
                setError("Lỗi khi tạo cơ sở dữ liệu: ${e.message}")
            }
        }
    }


    fun isFileAlreadyExists(): Boolean {
        val filePath = "$storagePath/$fileName.kdbx"
        val file = File(filePath)
        return file.exists()
    }

    fun isFieldsValid(): Boolean {
        if (fileName.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
            filenameError = if (fileName.isBlank()) "File name not blank" else ""

            passwordError = if (password.isBlank()) "Pass word is not blank" else ""

            confirmationError = if (confirmPassword.isBlank()) "Pass word is not blank" else ""

            return false
        }

        filenameError = ""
        passwordError = ""

        confirmationError = if (password == confirmPassword) {
            ""
        } else {
            "password not match"
        }

        return filenameError == "" &&
                passwordError == "" &&
                confirmationError == ""
    }


    private fun createDbFile(): FileDescriptor {

        val name = fileName
        val path = createPath(
            parentPath = storagePath,
            name = "$name.kdbx"
        )

        return FileDescriptor(
            fsAuthority = INTERNAL_FS_AUTHORITY,
            path = path,
            uid = path,
            name = FileUtils.getFileNameFromPath(path),
            isDirectory = false,
            isRoot = false,
            modified = null
        )
    }

    private sealed interface SelectedStorage {
        data class ParentDir(val dir: FileDescriptor) : SelectedStorage
        data class File(val file: FileDescriptor) : SelectedStorage
    }
}