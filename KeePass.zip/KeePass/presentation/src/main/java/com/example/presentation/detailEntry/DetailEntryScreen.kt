package com.example.presentation.detailEntry

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import com.example.presentation.R
import com.example.base.BaseScreen
import com.example.presentation.detailEntry.component.DetailEntryItem
import com.example.presentation.nav.AppTopBar

@Composable
fun DetailEntryScreen(
    navController: NavController,
    viewModel: DetailEntryViewModel
) {
    val entry by viewModel.entry.collectAsState()
    BaseScreen {
        Scaffold(
            topBar = {
                AppTopBar("${entry?.fields?.password?.content}", navController)
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                DetailEntryItem(
                    iconResId = R.drawable.ic_account,
                    title = "Tên người dùng",
                    value = "${entry?.fields?.userName?.content}",
                )

                DetailEntryItem(
                    iconResId = R.drawable.ic_password_out_line,
                    title = "Mật khẩu",
                    value = "${entry?.fields?.password?.content}",
                    isPassword = true
                )

                DetailEntryItem(
                    iconResId = R.drawable.ic_calendar,
                    title = "Đã tạo",
                    value = "${entry?.fields?.password?.content}",
                    isShowCopy = false
                )

                DetailEntryItem(
                    iconResId = R.drawable.ic_edit_calendar,
                    title = "Đã chỉnh sửa",
                    value = "${entry?.fields?.password?.content}",
                    isShowCopy = false
                )
            }
        }
    }

}
