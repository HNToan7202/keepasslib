package com.example.presentation.newPassword

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewModelScope
import app.keemobile.kotpass.constants.BasicField
import app.keemobile.kotpass.models.Entry
import app.keemobile.kotpass.models.EntryFields
import app.keemobile.kotpass.models.EntryValue
import com.example.data.repository.keepass.kotpass.KeepassDatabaseRepository
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject
import kotlin.random.Random

@HiltViewModel
class NewPasswordViewModel @Inject constructor(
    private val keepassDatabaseRepository: KeepassDatabaseRepository
) : BaseViewModel() {

    enum class EntryMode { CREATE, EDIT }

    var mode by mutableStateOf(EntryMode.CREATE)
    private var existingEntry: Entry? = null

    var title by mutableStateOf("")
    var url by mutableStateOf("")
    var note by mutableStateOf("")
    var userName by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmPassword by mutableStateOf("")

    var isPasswordVisible by mutableStateOf(false)
    var isConfirmPasswordVisible by mutableStateOf(false)

    fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
    }

    fun toggleConfirmPasswordVisibility() {
        isConfirmPasswordVisible = !isConfirmPasswordVisible
    }

    fun updateTitle(titleValue: String) {
        title = titleValue
    }

    fun updateNote(noteValue: String) {
        note = noteValue
    }

    fun updateURL(urlValue: String) {
        url = urlValue
    }

    fun updateUserName(userNameValue: String) {
        userName = userNameValue
    }

    fun updatePassword(passwordValue: String) {
        password = passwordValue
    }

    fun updateConfirmPassword(passwordValue: String) {
        confirmPassword = passwordValue
    }

    fun randomColorHex(): String {
        val r = (64..255).random()
        val g = (64..255).random()
        val b = (64..255).random()
        return String.format("#%02X%02X%02X", r, g, b)
    }


    fun submit() {
        if (password != confirmPassword) {
            setError("Passwords do not match")
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            setLoading()
            val randomColor = randomColorHex()
            val entry = when (mode) {
                EntryMode.CREATE -> Entry(
                    uuid = UUID.randomUUID(),
                    previousParentGroup = keepassDatabaseRepository.getRootGroupId(),
                    fields = buildFields(),
                    backgroundColor = randomColor
                )

                EntryMode.EDIT -> {
                    existingEntry?.copy(fields = buildFields()) ?: run {
                        setError("Entry to update not found")
                        return@launch
                    }
                }
            }

            val result = when (mode) {
                EntryMode.CREATE -> keepassDatabaseRepository.addEntryToGroup(entry)
                EntryMode.EDIT -> keepassDatabaseRepository.updateEntry(entry)
            }

            if (result.isSucceeded) {
                setSuccess()
            } else {
                setError("Failed to ${mode.name.lowercase()} entry")
            }
        }
    }

    private fun buildFields(): EntryFields {
        return EntryFields.of(
            BasicField.Title() to EntryValue.Plain(title),
            BasicField.UserName() to EntryValue.Plain(userName),
            BasicField.Password() to EntryValue.Plain(password),
            BasicField.Url() to EntryValue.Plain(url),
            BasicField.Notes() to EntryValue.Plain(note)
        )
    }

    fun loadEntryIfNeeded(uid: UUID) {
        if (mode == EntryMode.EDIT && existingEntry?.uuid == uid) return

        viewModelScope.launch(Dispatchers.IO) {
            setLoading()
            val result = keepassDatabaseRepository.getRootEntryById(uid).firstOrNull()
            if (result != null) {
                existingEntry = result
                mode = EntryMode.EDIT
                title = result.fields.title?.content ?: ""
                userName = result.fields.userName?.content ?: ""
                password = result.fields.password?.content ?: ""
                confirmPassword = password
                url = result.fields.url?.content ?: ""
                note = result.fields.notes?.content ?: ""

                setSuccess()
            } else {
                setError("Entry not found")
            }
        }
    }
}
