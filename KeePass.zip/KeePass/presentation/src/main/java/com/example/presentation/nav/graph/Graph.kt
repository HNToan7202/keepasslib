package com.example.presentation.nav.graph

import kotlinx.serialization.Serializable

sealed interface Graph {

    @Serializable
    data object ExitsFile : Graph

    @Serializable
    data object NonExitsFile : Graph

}
