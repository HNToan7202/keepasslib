package com.example.presentation.detailEntry

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import app.keemobile.kotpass.models.Entry
import com.example.data.repository.keepass.kotpass.KeepassDatabaseRepository
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class DetailEntryViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val keepassDatabaseRepository: KeepassDatabaseRepository
) : BaseViewModel() {

    private val _entry = MutableStateFlow<Entry?>(null)
    val entry: StateFlow<Entry?> = _entry

    init {
        val uid = savedStateHandle.get<String>("uid")?.let { UUID.fromString(it) }
        uid?.let {
            viewModelScope.launch {
                keepassDatabaseRepository.getRootEntryById(it)
                    .collect { result ->
                        _entry.value = result
                    }
            }
        }
    }
}
