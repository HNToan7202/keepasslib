package com.example.presentation.nav

import androidx.navigation.NavController

fun NavController.navigateWithState(route: Screen) {
    navigate(route) {
        popUpTo(graph.startDestinationId) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

fun <T : Any> NavController.replace(route: T) {
    navigate(route) {
        popUpTo(0) { inclusive = true }
        launchSingleTop = true
    }
}
