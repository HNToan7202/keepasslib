package com.example.presentation.passwordGeneratorScreen

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.presentation.base.GeneratePasswordConfig
import com.example.presentation.base.generateRandomPassword
import com.example.presentation.base.getPasswordStrengthColor
import com.example.presentation.base.getPasswordStrengthColorDark
import com.example.presentation.base.getPasswordStrengthText
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class PasswordGeneratorViewModel @Inject constructor() : BaseViewModel() {

    var state by mutableStateOf(PasswordGeneratorState())
        private set

    init {
        onInit()
    }


    private fun onInit() {
        with(state) {
            state = state.copy(
                password = com.example.presentation.base.generateRandomPassword(
                    GeneratePasswordConfig(
                        passwordLength,
                        includeLowercase,
                        includeUppercase,
                        includeNumbers,
                        includeSymbols
                    )
                ),
                passwordStrengthText = getPasswordStrengthText(passwordLength),
                passwordStrengthColor = getPasswordStrengthColor(passwordLength),
                passwordStrengthColorDark = getPasswordStrengthColorDark(passwordLength)
            )
        }
    }

}