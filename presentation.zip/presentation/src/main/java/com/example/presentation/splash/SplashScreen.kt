package com.example.presentation.splash

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.base.BaseScreen
import com.example.presentation.R
import com.example.presentation.nav.Screen
import com.example.presentation.theme.Dimens
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@Composable
fun SplashScreen(navController: NavController, viewModel: SplashViewModel = hiltViewModel()) {

    navController.navigate(
        if (viewModel.getLastFilePath() !=  null) {
            val encodedFilePath = URLEncoder.encode(viewModel.getLastFilePath(), StandardCharsets.UTF_8.toString())
            Screen.OpenDatabaseScreen.route + "/${viewModel.getLastFileName()}/${encodedFilePath}"
        } else Screen.OpenDatabaseScreen.route
    ) {

    }

    BaseScreen {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(Dimens.PaddingLarge),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.password_manager),
                modifier = Modifier
                    .padding(top = 70.dp)
                    .width(120.dp)
                    .height(120.dp),
                contentDescription = null
            )
        }
    }
}