package com.example.presentation.nav

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.utils.StringUtils
import com.example.presentation.components.BottomNavigationBar
import com.example.presentation.databaseSetting.DatabaseSettingScreen
import com.example.presentation.detailEntry.DetailEntryScreen
import com.example.presentation.home.HomeScreen
import com.example.presentation.newPassword.NewAndUpdatePasswordScreen
import com.example.presentation.newPassword.NewPasswordViewModel
import com.example.presentation.newdb.NewDatabaseScreen
import com.example.presentation.openDatabase.OpenDatabaseScreen
import com.example.presentation.openandnew.OpenAndNewScreen
import com.example.presentation.passwordGeneratorScreen.PasswordGeneratorScreen
import com.example.presentation.splash.SplashScreen
import com.example.presentation.splash.SplashViewModel
import com.example.presentation.storage.SelectStorageScreen
import java.util.UUID

@Composable
fun Navigation() {
    val navController = rememberNavController()
    val viewModel = hiltViewModel<SplashViewModel>()
    val route = if (viewModel.getLastFilePath() != null) {
        Screen.OpenDatabaseScreen.route + "/${viewModel.getLastFileName()}/${
            StringUtils.encodeFilePath(
                "${viewModel.getLastFilePath()}"
            )
        }"
    } else {
        Screen.OpenAndNewScreen.route
    }
    Scaffold(
        bottomBar = {
            BottomNavigationBar(navController)
        }
    ) { contentPadding ->
        NavHost(
            navController = navController,
            startDestination = route,
            modifier = Modifier.padding(contentPadding),
        ) {

            composable(Screen.OpenAndNewScreen.route) {
                OpenAndNewScreen(
                    navController = navController,
                    viewModel = hiltViewModel(),
                )
            }

            composable(Screen.NewDatabaseScreen.route) {
                NewDatabaseScreen(
                    navController = navController,
                    viewModel = hiltViewModel(),
                )
            }

            composable(Screen.StorageListScreen.route) {
                SelectStorageScreen(
                    navController = navController,
                    viewModel = hiltViewModel(),
                )
            }
            composable(Screen.HomeScreen.route) {
                HomeScreen(
                    navController = navController,
                    viewModel = hiltViewModel(),
                )
            }

            composable(Screen.DatabaseSettingScreen.route) {
                DatabaseSettingScreen(navController)
            }

            composable(Screen.PasswordGeneratorScreen.route) {
                PasswordGeneratorScreen(navController)
            }

            composable(Screen.SplashScreen.route) {
                SplashScreen(navController)
            }

            composable(
                Screen.OpenDatabaseScreen.route + "/{fileName}/{filePath}",
                arguments = listOf(
                    navArgument("fileName") { type = NavType.StringType },
                    navArgument("filePath") { type = NavType.StringType }
                )) { backEntry ->
                val fileName = backEntry.arguments?.getString("fileName")
                val filePath = backEntry.arguments?.getString("filePath")
                OpenDatabaseScreen(
                    navController = navController,
                    fileName = fileName,
                    filePath = filePath,
                )
            }

            composable(
                Screen.DetailEntryScreen.route + "/{uid}",
                arguments = listOf(navArgument("uid") {
                    type =
                        NavType.StringType
                })
            ) { backEntry ->
                DetailEntryScreen(
                    navController = navController,
                    viewModel = hiltViewModel(),
                )
            }

            composable(
                route = "${Screen.NewPasswordScreen.route}/{${Screen.NewPasswordScreen.MODE}}/{${Screen.NewPasswordScreen.ENTRY_UID}}",
                arguments = listOf(
                    navArgument(Screen.NewPasswordScreen.MODE) { type = NavType.StringType },
                    navArgument(Screen.NewPasswordScreen.ENTRY_UID) {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = ""
                    }
                )
            ) { backEntry ->

                val mode =
                    backEntry.arguments?.getString(Screen.NewPasswordScreen.MODE) ?: "create"
                val uid = backEntry.arguments?.getString(Screen.NewPasswordScreen.ENTRY_UID)
                    .takeIf { it?.isNotBlank() == true }

                val viewModel = hiltViewModel<NewPasswordViewModel>()

                if (mode == "edit" && uid != null) {
                    viewModel.loadEntryIfNeeded(UUID.fromString(uid))
                }

                NewAndUpdatePasswordScreen(
                    navController = navController,
                    viewModel = viewModel,
                    isEditMode = mode == "edit"
                )
            }
        }


    }

}