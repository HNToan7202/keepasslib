package com.example.presentation.storage

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.data.utils.StringUtils
import com.example.presentation.nav.AppTopBar
import com.example.presentation.nav.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SelectStorageScreen(
    navController: NavController?,
    viewModel: SelectStorageViewModel
) {
    val context = LocalContext.current
    val internalFiles = remember {
        context.filesDir.listFiles()?.filter { it.extension == "kdbx" } ?: emptyList()
    }

    Scaffold(
        topBar = { AppTopBar("Chọn file từ bộ nhớ nội bộ", navController) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "${context.filesDir.absolutePath}",
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (internalFiles.isEmpty()) {
                Text("Không tìm thấy file .kdbx nào.")
            } else {
                LazyColumn {
                    items(internalFiles.size) { index ->
                        val file = internalFiles[index]

                        ListItem(
                            headlineContent = { Text(file.name) },
                            supportingContent = { Text("Kích thước: ${file.length() / 1024} KB") },
                            leadingContent = {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null
                                )
                            },
                            trailingContent = {
                                val formatter = SimpleDateFormat("dd/MM", Locale.getDefault())
                                val formattedDate = formatter.format(Date(file.lastModified()))
                                Text(formattedDate)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.onFileSelected(file, index)
                                    navController?.navigate(Screen.OpenDatabaseScreen.route +"/${file.name}/${StringUtils.encodeFilePath(file.absolutePath)}")
                                }
                        )
                    }
                }
            }
        }
    }
}

@Preview(showSystemUi = true)
@Composable
fun SelectStorageScreenPreview() {
    SelectStorageScreen(
        navController = null,
        viewModel = hiltViewModel()
    )
}
