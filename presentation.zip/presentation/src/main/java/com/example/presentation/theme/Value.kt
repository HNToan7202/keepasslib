package com.example.presentation.theme

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.ui.unit.dp

// Padding
val pagePadding = 16.dp

// Window Insets
val windowInsetsVerticalZero = WindowInsets(top = 0.dp, bottom = 0.dp)
