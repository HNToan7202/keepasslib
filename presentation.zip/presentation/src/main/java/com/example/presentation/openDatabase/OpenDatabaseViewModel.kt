package com.example.presentation.openDatabase

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewModelScope
import app.keemobile.kotpass.cryptography.EncryptedValue
import app.keemobile.kotpass.database.Credentials
import app.keemobile.kotpass.database.KeePassDatabase
import app.keemobile.kotpass.database.decode
import com.example.data.entity.FSAuthority.Companion.INTERNAL_FS_AUTHORITY
import com.example.data.entity.FileDescriptor
import com.example.data.file.FSOptions
import com.example.data.file.sharedreferences.FileViewModel
import com.example.data.repository.SharedPreferencesRepository
import com.example.data.repository.keepass.PasswordKeepassKey
import com.example.data.repository.keepass.kotpass.KeepassDatabaseRepository
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class OpenDatabaseViewModel @Inject constructor(
    private val keepassDatabaseRepository: KeepassDatabaseRepository,
    private val sharedPreferencesRepository: SharedPreferencesRepository
) : BaseViewModel() {

    private val isExistFile = Channel<Boolean>()
    val hasExistFile = isExistFile.receiveAsFlow()


    var file: File? = null

    init {
        getHasExistFile()
    }

    fun getHasExistFile() {
        viewModelScope.launch {
            val filePath = sharedPreferencesRepository.getLastFilePath()
            if (filePath != null) {
                isExistFile.send(true)
                file = File(filePath)
            }
        }
    }

    fun getLastFilePath(): String? {
        return sharedPreferencesRepository.getLastFilePath()
    }


    var password by mutableStateOf<String>("")

    var isPasswordVisible by mutableStateOf(false)


    fun updatePassword(passwordValue: String) {
        password = passwordValue
    }


    fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
    }

    fun isSelectFile(): Boolean {
        return sharedPreferencesRepository.getLastFilePath() == null
    }

    fun openDatabase(file: File) {

        viewModelScope.launch(Dispatchers.IO) {
            setLoading()
            try {
                val credentials = Credentials.from(EncryptedValue.fromString(password))

                val database =
                    file.inputStream().use {
                        KeePassDatabase.decode(it, credentials)
                    }

                val dbKey = PasswordKeepassKey(password)
                keepassDatabaseRepository.setDatabase(
                    db = database,
                    fsOptions = FSOptions.DEFAULT,
                    dbFile = file.toFileDescriptor(),
                    key = dbKey
                )
                setSuccess()
            } catch (e: Exception) {
                setError("Lỗi khi mở cơ sở dữ liệu: ${e.message}")
            }
        }
    }

    private fun File.toFileDescriptor(): FileDescriptor {
        return FileDescriptor(
            fsAuthority = INTERNAL_FS_AUTHORITY,
            path = path,
            uid = path,
            name = name,
            isDirectory = isDirectory,
            isRoot = true,
            modified = lastModified()
        )
    }


}