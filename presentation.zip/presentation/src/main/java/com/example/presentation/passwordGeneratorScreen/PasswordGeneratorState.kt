package com.example.presentation.passwordGeneratorScreen

import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color
import com.example.base.EMPTY_STRING
import com.example.presentation.R


data class PasswordGeneratorState(
    val password: String = EMPTY_STRING,
    val passwordLength: Int = 8,
    val includeLowercase: Boolean = true,
    val includeUppercase: Boolean = true,
    val includeNumbers: Boolean = true,
    val includeSymbols: Boolean = true,
    @StringRes val passwordStrengthText: Int = R.string.text_weak,
    val passwordStrengthColor: Color = Color.Transparent,
    val passwordStrengthColorDark: Color = Color.Transparent
)
