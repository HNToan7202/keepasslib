package com.example.presentation.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.presentation.R
import com.example.presentation.nav.Screen

@Composable
fun BottomNavigationBar(navController: NavController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    var bottomBarVisible by rememberSaveable { mutableStateOf(true) }

    val currentRoute = navBackStackEntry?.destination?.route

    // Kiểm tra điều kiện để ẩn hoặc hiển thị bottomBar
    bottomBarVisible = when (currentRoute) {
        Screen.HomeScreen.route,
        Screen.PasswordGeneratorScreen.route,
        Screen.DatabaseSettingScreen.route -> true

        else -> false
    }

    // Chỉ hiển thị BottomNavigation khi bottomBarVisible là true
    if (bottomBarVisible) {
        NavigationBar {
            NavigationBarItem(
                label = { Text(stringResource(R.string.nav_home)) },
                icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                selected = currentRoute == Screen.HomeScreen.route,
                onClick = {
                    navController.navigate(Screen.HomeScreen.route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
            NavigationBarItem(
                label = { Text(stringResource(R.string.nav_generator)) },
                icon = { Icon(Icons.Filled.Lock, contentDescription = "Password Generator") },
                selected = currentRoute == Screen.PasswordGeneratorScreen.route,
                onClick = {
                    navController.navigate(Screen.PasswordGeneratorScreen.route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
            NavigationBarItem(
                label = { Text(stringResource(R.string.nav_settings)) },
                icon = { Icon(Icons.Filled.Settings, contentDescription = "Database Settings") },
                selected = currentRoute == Screen.DatabaseSettingScreen.route,
                onClick = {
                    navController.navigate(Screen.DatabaseSettingScreen.route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}