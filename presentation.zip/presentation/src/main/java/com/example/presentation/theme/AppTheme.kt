package com.example.presentation.theme

import androidx.compose.ui.graphics.Color

val PrimaryColor = Color(0xff2f9d68)      // Xanh đậm
val OnPrimaryColor = Color.White          // Chữ trên nền chính

// Màu phụ
val SecondaryColor = Color(0xFF00ACC1)    // Xanh nhạt
val OnSecondaryColor = Color.White

// Màu nền App
val BackgroundColor = Color(0xFFF5F5F5)    // Xám sáng
val SurfaceColor = Color.White

// Màu lỗi
val ErrorColor = Color(0xFFD32F2F)


