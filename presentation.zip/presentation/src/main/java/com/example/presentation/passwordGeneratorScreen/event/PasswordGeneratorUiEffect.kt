package com.example.presentation.passwordGeneratorScreen.event

import androidx.annotation.StringRes

sealed class PasswordGeneratorUiEffect {
    data class CopyToClipboard(val text: String) : PasswordGeneratorUiEffect()
    data class ShowSnackbarMessage(@StringRes val message: Int) : PasswordGeneratorUiEffect()
}
