package com.example.data.repository.ancdb

import android.os.Parcelable
import com.example.data.entity.KeyType

interface EncryptedDatabaseKey : Parcelable {
    val type: KeyType
}