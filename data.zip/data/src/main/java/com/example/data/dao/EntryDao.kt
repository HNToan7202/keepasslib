package com.example.data.dao

import app.keemobile.kotpass.models.Entry
import com.example.data.result.OperationResult
import java.util.UUID

interface EntryDao {
    fun insert(note: Entry): OperationResult<UUID?>

    fun remove(noteUid: UUID): OperationResult<Boolean>

    fun getEntryById(noteUid: UUID): OperationResult<Entry?>

    fun update(newNote: Entry, doCommit: Boolean): OperationResult<Entry>
}