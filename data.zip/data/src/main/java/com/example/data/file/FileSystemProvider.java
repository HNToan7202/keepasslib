package com.example.data.file;

import androidx.annotation.NonNull;


import com.example.data.entity.FileDescriptor;
import com.example.data.result.OperationResult;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

public interface FileSystemProvider {


    @NonNull
    OperationResult<InputStream> openFileForRead(
            @NonNull FileDescriptor file,
            @NonNull OnConflictStrategy onConflictStrategy,
            @NonNull FSOptions options);

    @NonNull
    OperationResult<OutputStream> openFileForWrite(
            @NonNull FileDescriptor file,
            @NonNull OnConflictStrategy onConflictStrategy,
            @NonNull FSOptions options);

    @NonNull
    OperationResult<Boolean> exists(@NonNull FileDescriptor file);

    @NonNull
    OperationResult<FileDescriptor> getFile(@NonNull String path, @NonNull FSOptions options);
}
