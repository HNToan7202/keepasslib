package com.example.data.file.sharedreferences

import androidx.lifecycle.ViewModel
import com.example.data.repository.SharedPreferencesRepository
import javax.inject.Inject

open class FileViewModel @Inject constructor(
    private val sharedPreferencesRepository: SharedPreferencesRepository
) : ViewModel() {

    fun saveLastOpenTime() {
        val currentTime = System.currentTimeMillis()
        sharedPreferencesRepository.saveLastOpenTime(currentTime)
    }

    fun getLastOpenTime(): Long {
        return sharedPreferencesRepository.getLastOpenTime()
    }
}