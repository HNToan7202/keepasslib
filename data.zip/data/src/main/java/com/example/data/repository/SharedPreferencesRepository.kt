package com.example.data.repository

import android.content.SharedPreferences
import androidx.core.content.edit
import javax.inject.Inject

class SharedPreferencesRepository @Inject constructor(
    private val sharedPreferences: SharedPreferences
) {

    fun saveLastOpenTime(time: Long) {
        sharedPreferences.edit {
            putLong("last_open_time", time)
        }
    }

    // Lấy thời gian mở file gần nhất
    fun getLastOpenTime(): Long {
        return sharedPreferences.getLong("last_open_time", -1)
    }

    fun saveLastFilePath(filePath: String) {
        sharedPreferences.edit {
            putString("last_file_path", filePath)
        }
    }

    fun getLastFilePath(): String? {
        return sharedPreferences.getString("last_file_path", null)
    }

    fun saveLastFileName(fileName: String) {
        sharedPreferences.edit {
            putString("last_file_name", fileName)
        }
    }

    // Lấy tên file mở gần nhất
    fun getLastFileName(): String? {
        return sharedPreferences.getString("last_file_name", null)
    }
}